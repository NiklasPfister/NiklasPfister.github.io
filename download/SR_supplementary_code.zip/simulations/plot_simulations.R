########################################################
###
### Plot simulation experiments
###
#######################################################

## Load packages
library(ggplot2)
library(cowplot)
library(ggthemes)
library(gridExtra)
library(ggpubr)
library(latex2exp)
library(extrafont)
library(scales)

font_install("fontcm")
loadfonts()
textwidth <- 15.91774/2.54
fontsize <- 9

## Plot theme
theme_set(theme_light())
theme_update(panel.grid.minor=element_blank(),
             panel.grid.major=element_line(size=0.05),
             strip.text = element_text(size=fontsize),
             plot.title = element_text(size=fontsize+1, hjust=0.5),
             axis.text.x = element_text(size=fontsize-1),
             axis.text.y = element_text(size=fontsize-1),
             text=element_text(family="CM Roman", size=fontsize))
cols <- hue_pal()(6)


run_prepare <- TRUE
run_plot <- TRUE

lowdim_name <- "_lowdim_linear_coef"
sparse_name <- "_sparse_linear_coef"



if(run_prepare){
  # load data
  suffix <- lowdim_name
  load(paste("results/simulation", suffix ,".Rda", sep=""))
  # remove bad results
  ind <- sapply(res, function(x) length(x)>1)
  res <- res[ind]
  if(sum(!ind)>0){
    warning(paste(sum(!ind), "results needed to be removed"))
  }
  len <- length(res)
  num_vars <- length(res[[1]][[3]]$var_score)
  # methods
  method_index <- which(sapply(res[[1]], function(x) !is.null(x$method)))
  method_labels <- sapply(res[[1]][method_index], function(x) x$method)
  
  ## ground truth lists
  SBlist <- vector("list", len)
  MBlist <- vector("list", len)
  NSBlist <- vector("list", len)
  ## true positives
  TP <- list()
  TP$SB <- lapply(1:length(method_labels),
                  function(x) matrix(NA, len, num_vars))
  TP$MB <- lapply(1:length(method_labels),
                  function(x) matrix(NA, len, num_vars))
  TP$NSB <- lapply(1:length(method_labels),
                   function(x) matrix(NA, len, num_vars))
  ## false positives
  FP <- list()
  FP$SB <- lapply(1:length(method_labels),
                  function(x) matrix(NA, len, num_vars))
  FP$MB <- lapply(1:length(method_labels),
                  function(x) matrix(NA, len, num_vars))
  FP$NSB <- lapply(1:length(method_labels),
                   function(x) matrix(NA, len, num_vars))
  ## setting vectors
  setting1 <- rep(FALSE, len)
  setting2 <- rep(FALSE, len)
  ## prediction results
  predmat_methods <- matrix(NA, len, length(method_labels))

  ## Iterate over results
  for(i in 1:length(res)){
    perm <- sample(1:num_vars)
    # Read-out ground truth
    SB <- perm[res[[i]][[1]]$SB]
    MB <- perm[res[[i]][[1]]$MB]
    NSB <- setdiff(MB, SB)
    SBlist[[i]] <- SB
    MBlist[[i]] <- MB
    NSBlist[[i]] <- NSB
    # Read-out settings
    if(length(SB) == length(MB)){
      setting1[i] <- TRUE
    }
    if(length(SB) > 0 & length(NSB) > 0){
      setting2[i] <- TRUE
    }
    # Methods (other than SR (NSB))
    for(j in 1:length(method_index)){
      ordering <- perm[order(res[[i]][[method_index[j]]]$var_score, decreasing=TRUE)]
      TP$SB[[j]][i,] <- (cumsum((ordering %in% SB))/length(SB))
      FP$SB[[j]][i,] <- cumsum(!(ordering %in% SB))
      TP$MB[[j]][i,] <- (cumsum((ordering %in% MB))/length(MB))
      FP$MB[[j]][i,] <- cumsum(!(ordering %in% MB))
      TP$NSB[[j]][i,] <- (cumsum((ordering %in% NSB))/length(NSB))
      FP$NSB[[j]][i,] <- cumsum(!(ordering %in% NSB))
      predmat_methods[i, j] <- res[[i]][[method_index[j]]]$pred
    }
  }
}


###
# Print information about the simulation
###

print("Setting sizes:")
print(sum(setting1))
print(sum(!setting1))
print(sum(setting2))


###
# Create plots
###

if(run_plot){
  # Select methods --> needs to correspond to method_labels (includecols)
  methodnames <- factor(c("SR", "SRpred", "SRdiff", "Lasso",
                          "OLS", "AR", "IV", "AR (Lasso)", "IV (Lasso)"))
  # Reorder methods so colors match
  methodnames = factor(methodnames,
                       levels(methodnames)[c(7,9,8,6,5,2,1,4,3)])
  #c(8, 9, 6, 7, 1, 3, 5, 2, 4)
  if(suffix == lowdim_name){
    include_pred <- which(methodnames %in% c("SR", "SRpred", "OLS", "IV", "AR"))
    include_vi <- which(methodnames %in% c("SR", "SRpred", "SRdiff", "OLS", "IV", "AR"))
  }
  else{
    include_pred <- which(methodnames %in% c("SR", "SRpred", "Lasso", "IV (Lasso)", "AR (Lasso)"))
    include_vi <- which(methodnames %in% c("SR", "SRpred", "SRdiff",
                                           "Lasso", "IV (Lasso)", "AR (Lasso)"))
  }

  ###
  # Prediction plots
  ###
  
  df1 <- data.frame(RSS=as.vector(predmat_methods[setting1, include_pred]),
                    Method=rep(methodnames[include_pred],
                               each=sum(setting1)),
                    type="SB(Y) equal to MB(Y)")
  df2 <- data.frame(RSS=as.vector(predmat_methods[!setting1, include_pred]),
                    Method=rep(methodnames[include_pred],
                               each=sum(!setting1)),
                    type="SB(Y) not equal to MB(Y)")
  df <- rbind(df1, df2)

  # pdf("ggplot_cm.pdf", width=textwidth, height=0.4*textwidth)
  pred_plot <- ggplot(df, aes(x=Method, y=RSS, fill=Method))
  pred_plot <- pred_plot + facet_grid(. ~ type)
  pred_plot <- pred_plot + geom_boxplot()
  pred_plot <- pred_plot + scale_fill_manual(values=cols[-3])
  pred_plot <- pred_plot + coord_cartesian(ylim=c(0,4))
  pred_plot <- pred_plot +  theme(legend.title = element_blank(),
                                  axis.text.x = element_text(size=fontsize-2),
                                  axis.title.x=element_blank(),
                                  legend.position="none")
  pred_plot <- pred_plot + ylab(TeX("mean RSS on test environments"))
  save_plot(paste("results/prediction_boxplot", suffix ,".pdf", sep=""),
            pred_plot,
            base_width=textwidth, base_height=0.4*textwidth)
  embed_fonts(paste("results/prediction_boxplot", suffix ,".pdf", sep=""),
              outfile=paste("results/prediction_boxplot",
                            suffix ,".pdf", sep=""))

  

  ###
  # pROC plots
  ###
  
  collected_data <- data.frame(FP=numeric(0),
                               TP_SB=numeric(0),
                               TP_NSP=numeric(0),
                               TP_MB=numeric(0),
                               Method=numeric(0))
  FPs <- 0:5
  avgTPs_SB <- vector("numeric", length(FPs))
  avgTPs_NSB <- vector("numeric", length(FPs))
  avgTPs_MB <- vector("numeric", length(FPs))
  for(j in include_vi){
    for(i in 1:length(FPs)){
      ind1 <- FP$SB[[j]][setting2,] <= FPs[i]
      ind2 <- FP$NSB[[j]][setting2,] <= FPs[i]
      ind3 <- FP$MB[[j]][setting2,] <= FPs[i]
      # SB true positives
      TP_SB <- vector("numeric", nrow(ind1))
      for(k in 1:nrow(ind1)){
        if(sum(ind1[k,]) == 0){
          TP_SB[k] <- 0
        }
        else{
          TP_SB[k] <- max(TP$SB[[j]][setting2,][k,][ind1[k,]])
        }
      }
      # NSB true positives
      TP_NSB <- vector("numeric", nrow(ind2))
      for(k in 1:nrow(ind2)){
        if(sum(ind2[k,]) == 0){
          TP_NSB[k] <- 0
        }
        else{
          TP_NSB[k] <- max(TP$NSB[[j]][setting2,][k,][ind2[k,]])
        }
      }
      # MB true positives
      TP_MB <- vector("numeric", nrow(ind3))
      for(k in 1:nrow(ind3)){
        if(sum(ind3[k,]) == 0){
          TP_MB[k] <- 0
        }
        else{
          TP_MB[k] <- max(TP$MB[[j]][setting2,][k,][ind3[k,]])
        }
      }
      avgTPs_SB[i] <- mean(TP_SB)
      avgTPs_NSB[i] <- mean(TP_NSB)
      avgTPs_MB[i] <- mean(TP_MB)
    }
    tmp <- data.frame(FP=FPs,
                      TP_SB=avgTPs_SB,
                      TP_NSB=avgTPs_NSB,
                      TP_MB=avgTPs_MB,
                      Method=rep(methodnames[j],
                                 length(FPs)))
    collected_data <- rbind(collected_data, tmp)
  }
  df <- rbind(data.frame(FP=collected_data$FP,
                         TPR=collected_data$TP_SB,
                         type=rep("SB", nrow(collected_data)),
                         Method=collected_data$Method),
              data.frame(FP=collected_data$FP,
                         TPR=collected_data$TP_NSB,
                         type=rep("NSB", nrow(collected_data)),
                         Method=collected_data$Method),
              data.frame(FP=collected_data$FP,
                         TPR=collected_data$TP_MB,
                         type=rep("MB", nrow(collected_data)),
                         Method=collected_data$Method))
  df$type <- factor(df$type)

  ## Generate facet plot
  type_labs <- c("SB(Y)", "NSB(Y)", "MB(Y)")
  names(type_labs) <- c("SB", "NSB", "MB")
  vs_plot <- ggplot(df, aes(x=FP, y=TPR, col=Method, shape=Method, linetype=Method))
  vs_plot <- vs_plot + scale_color_manual(values=cols)
  vs_plot <- vs_plot + facet_grid(. ~ type, labeller=ggplot2::labeller(.cols=type_labs))
  vs_plot <- vs_plot + geom_point(alpha=0.5, size=2) + geom_line()
  vs_plot <- vs_plot + ylab(TeX("true positive recovery"))
  vs_plot <- vs_plot + xlab(TeX("number of false discoveries"))
  vs_plot <- vs_plot + theme(legend.title = element_blank())
  
  save_plot(paste("results/variable_selection", suffix ,".pdf", sep=""),
            vs_plot,
            base_width=textwidth, base_height=0.4*textwidth)
  embed_fonts(paste("results/variable_selection", suffix ,".pdf", sep=""),
              outfile=paste("results/variable_selection",
                            suffix ,".pdf", sep=""))

}

