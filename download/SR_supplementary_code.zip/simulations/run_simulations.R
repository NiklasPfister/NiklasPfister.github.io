########################################################
###
### Run simulation experiments
###
#######################################################


## load packages and functions
library(parallel)
library(StabilizedRegression)
library(seqICP)
library(glmnet)
library(R.utils)
source("generate_data.R")
source("utils.R")


###
# Simulation function
###

single_iteration <- function(i, B, m, prescreen_size,
                             prescreen_type, stab_test, pred_score,
                             alpha_stab, alpha_pred,
                             variable_importance, d, n,
                             intervention_par, parent_par, num_train,
                             num_test, intshift_train, intshift_test,
                             type){

  print(i)
  seed <- i
  set.seed(seed)
  verbose <- FALSE
  
  ## Generate random sample
  if(type=="lowdim"){
    data <- linear_DAG_model_stable(d=d, n=n, num_intvars=intervention_par,
                                    max_num_parents=parent_par,
                                    num_train=num_train, num_test=num_test,
                                    intshift_train=intshift_train, intshift_test=intshift_test)
  }
  else if(type=="sparse"){
    data <- linear_DAG_model_sparse(d=d, n=n, intprob=intervention_par,
                                    p_connect=parent_par,
                                    num_train=num_train, num_test=num_test,
                                    intshift_train=intshift_train, intshift_test=intshift_test)    
  }
  
  PA <- data$PA
  CH <- data$CH
  interventions <- data$interventions
  SB <- data$SB
  MB <- data$MB
  testset <- data$env > num_train
  trainset <- data$env <= num_train

  ## print(PA)
  ## print(CH)
  ## print(SB)
  ## print(MB)
  ## print(interventions)
  
  ## Define result lists
  res <- vector("list", 9)
  res[[1]] <- list(PA=PA,
                   CH=CH,
                   interventions=interventions,
                   SB=SB,
                   MB=MB,
                   DAGmat=data$B,
                   n=n,
                   d=d,
                   num_train=num_train,
                   num_test=num_test,
                   m=m,
                   intervention_par=intervention_par,
                   parent_par=parent_par,
                   B=B,
                   prescreen_size=prescreen_size,
                   prescreen_type=prescreen_type,
                   parent_par=parent_par,
                   stab_test=stab_test,
                   pred_score=pred_score,
                   alpha_stab=alpha_stab,
                   alpha_pred=alpha_pred,
                   variable_importance=variable_importance,
                   type=type,
                   seed=seed)

  ## Linear regression (truth)
  # parents
  df1 <- data.frame(Y=data$Y[trainset], X=data$X[trainset, PA])
  fit1 <- lm(Y ~ -1 + ., data=df1)
  # stable and predictive
  df2 <- data.frame(Y=data$Y[trainset], X=data$X[trainset, SB])
  fit2 <- lm(Y ~ -1 + ., data=df2)
  # Markov blanket
  df3 <- data.frame(Y=data$Y[trainset], X=data$X[trainset, MB])
  fit3 <- lm(Y ~ -1 + ., data=df3)
  # all
  df4 <- data.frame(Y=data$Y[trainset], X=data$X[trainset,])
  fit4 <- lm(Y ~ -1 + ., data=df4)
  # Predict
  df1 <- data.frame(X=data$X[testset, PA])
  df2 <- data.frame(X=data$X[testset, SB])
  df3 <- data.frame(X=data$X[testset, MB])
  df4 <- data.frame(X=data$X[testset,])
  res[[2]] <- list(pred_PA=mean((predict(fit1, df1) - data$Y[testset])^2),
                   pred_SB=mean((predict(fit2, df2) - data$Y[testset])^2),
                   pred_MB=mean((predict(fit3, df3) - data$Y[testset])^2),
                   pred_all=mean((predict(fit4, df4) - data$Y[testset])^2))
                   
  ## Stabilized regression
  fit <- StabilizedRegression(data$X[trainset,], data$Y[trainset],
                              as.factor(data$env[trainset]),
                              list(m=m, B=B,
                                   alpha_stab=alpha_stab,
                                   alpha_pred=alpha_pred,
                                   size_weight="linear",
                                   prescreen_size=prescreen_size,
                                   prescreen_type=prescreen_type,
                                   use_resampling=FALSE,
                                   compute_predictive_model=TRUE,
                                   stab_test=stab_test,
                                   pred_score=pred_score,
                                   variable_importance=variable_importance),
                              verbose=verbose)

  res[[3]] <- list(var_score=fit$variable_importance,
                   pred=mean((predict(fit, data$X[testset,]) - data$Y[testset])^2),
                   method="SR")
  res[[4]] <- list(var_score=fit$variable_importance_pred,
                   pred=mean((predict(fit, data$X[testset,],
                                      predictive_model=TRUE) - data$Y[testset])^2),
                   method="SR (nostab)")
  res[[5]] <- list(var_score=fit$variable_importance_diff,
                   pred=NA,
                   method="SR (diff)")
    
  ## Lasso regression
  fit <- lasso_variable_selection(data$X[trainset,], data$Y[trainset])
  res[[6]] <- list(var_score=abs(coefficients(fit$fit)[-1]*apply(data$X[trainset,], 2, sd)),
                   #var_score=-fit$first.entrance,
                   pred=mean((predict(fit$fit, data$X[testset,],
                                      s="lambda.min") - data$Y[testset])^2),
                   method="Lasso")
  
  ## Linear regression
  df <- data.frame(Y=data$Y, data$X)
  fit <- lm(Y~., data=df[trainset,])
  res[[7]] <- list(var_score=abs(coefficients(fit)[-1]*apply(data$X[trainset,], 2, sd)),
                   #var_score=1-summary(fit)$coefficients[-1,'Pr(>|t|)'],
                   pred=mean((predict(fit, df[testset,]) - data$Y[testset])^2),
                   method="OLS")

  if(type=="lowdim"){
    ## Anchor regression
    fit <- cv.anchor.regression(cbind(rep(1, sum(trainset)), 
                                      data$X[trainset,]),
                                data$Y[trainset], data$env[trainset])
    res[[8]] <- list(var_score=abs(fit[-1]*apply(data$X[trainset,], 2, sd)),
                     pred=mean((
                       cbind(rep(1, sum(testset)), 
                             data$X[testset,]) %*%
                         matrix(fit, ncol=1) - data$Y[testset])^2),
                     method="AR")
    
    ## Instrumental variables
    fit <- anchor.regression(cbind(rep(1, sum(trainset)), 
                                   data$X[trainset,]),
                             data$Y[trainset], data$env[trainset], gamma=1000)
    res[[9]] <- list(var_score=abs(fit[-1]*apply(data$X[trainset,], 2, sd)),
                     pred=mean((
                       cbind(rep(1, sum(testset)), 
                             data$X[testset,]) %*%
                         matrix(fit, ncol=1) - data$Y[testset])^2),
                     method="IV")
  }
  else{
    res[[8]] <- list(var_score=NA,
                     pred=NA,
                     method="AR")
    res[[9]] <- list(var_score=NA,
                     pred=NA,
                     method="IV")
  }

  ## Anchor regression (highdim)
  fit <- cv.anchor.regression(cbind(rep(1, sum(trainset)), 
                                    data$X[trainset,]),
                              data$Y[trainset], data$env[trainset], highdim=TRUE)
  res[[10]] <- list(var_score=abs(fit[-1]*apply(data$X[trainset,], 2, sd)),
                    pred=mean((
                      cbind(rep(1, sum(testset)), 
                            data$X[testset,]) %*%
                        matrix(fit, ncol=1) - data$Y[testset])^2),
                    method="AR_lasso")
  
  ## Instrumental variables (highdim)
  fit <- anchor.regression(cbind(rep(1, sum(trainset)), 
                                 data$X[trainset,]),
                           data$Y[trainset], data$env[trainset], gamma=1000, highdim=TRUE)
  res[[11]] <- list(var_score=abs(fit[-1]*apply(data$X[trainset,], 2, sd)),
                    pred=mean((
                      cbind(rep(1, sum(testset)), 
                            data$X[testset,]) %*%
                        matrix(fit, ncol=1) - data$Y[testset])^2),
                    method="IV_lasso")
  
  
  if(verbose){
    print(PA)
    print(SB)
    print(MB)
    print("results")
    print(order(res[[3]]$var_score, decreasing=T))
    print(order(res[[4]]$var_score, decreasing=T))
    print(order(res[[6]]$var_score, decreasing=T))
    print(order(res[[7]]$var_score, decreasing=T))
    print(order(res[[8]]$var_score, decreasing=T))
    print(order(res[[9]]$var_score, decreasing=T))
    print(order(res[[10]]$var_score, decreasing=T))
    print(order(res[[11]]$var_score, decreasing=T))
    print("scores")
    print(sort(res[[3]]$var_score, decreasing=T))
    print("unstable")
    print(order(res[[4]]$var_score-res[[3]]$var_score, decreasing=T))
  }

  print("loss")
  print(c(res[[3]]$pred, res[[4]]$pred, res[[6]]$pred, res[[7]]$pred,
          res[[8]]$pred, res[[9]]$pred, res[[10]]$pred, res[[11]]$pred))
  print("SB")
  print(SB)
  print("MB")
  print(MB)
  print("Done")
  if(verbose){
    readline("Press enter")
    #print("done")
  }
  
  return(res)
  
}

## Set paramters
num_reps <- 1000
cores <- 50
exp1 <- FALSE
exp2 <- FALSE
exp3 <- TRUE

###
# Run simulation - lowdim
###

if(exp1){
  res <- mclapply(1:num_reps,
                  function(i)
                    single_iteration(i, B=NA, m=10, prescreen_size=NA, prescreen_type="lasso",
                                     stab_test="mean_sres", pred_score=c("mse", "mse_env"),
                                     alpha_stab=0.01, alpha_pred=0.01,
                                     variable_importance="scaled_coefficient",
                                     d=10, n=250, intervention_par=4, parent_par=4,
                                     num_train=5, num_test=10, intshift_train=1, intshift_test=10,
                                     type="lowdim"),
                  mc.cores=cores, mc.preschedule=FALSE)
  save(res, file="results/simulation_lowdim_linear_coef.Rda")
}


###
# Run simulation - sparse
###

if(exp2){
  res <- mclapply(1:num_reps,
                  function(i)
                    single_iteration(i, B=NA, m=10, prescreen_size=10, prescreen_type="lasso",
                                     stab_test="mean_sres", pred_score=c("mse", "mse_env"),
                                     alpha_stab=0.01, alpha_pred=0.01,
                                     variable_importance="scaled_coefficient",
                                     d=1000, n=100, intervention_par=0.5, parent_par=2/1000,
                                     num_train=5, num_test=10, intshift_train=1, intshift_test=10,
                                     type="sparse"),
                  mc.cores=cores, mc.preschedule=FALSE)
  save(res, file="results/simulation_sparse_linear_coef.Rda")
}


###
# Run simulation - lowdim, high stability cutoff
###

if(exp3){
  res <- mclapply(1:num_reps,
                  function(i)
                    single_iteration(i, B=NA, m=10, prescreen_size=NA, prescreen_type="lasso",
                                     stab_test="mean_sres", pred_score=c("mse", "mse_env"),
                                     alpha_stab=0.1, alpha_pred=0.01,
                                     variable_importance="scaled_coefficient",
                                     d=10, n=250, intervention_par=4, parent_par=4,
                                     num_train=5, num_test=10, intshift_train=1, intshift_test=10,
                                     type="lowdim"),
                  mc.cores=cores, mc.preschedule=FALSE)
  save(res, file="results/simulation_lowdim_linear_coef_high_stabcutoff.Rda")
}
