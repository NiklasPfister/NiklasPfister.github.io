########################################################
###
### Functions to simulate interventional data
###
#######################################################
library(pcalg)
library(igraph)

###
# Linear DAG model
###

linear_DAG_model_stable <- function(d=10, num_intvars=3, num_train=3, num_test=2,
                                    n=100, max_num_parents=1,
                                    intshift_train=0.5, intshift_test=0.5){
  
  # Generate environment vector
  num_env <- num_train + num_test
  env <- rep(1:num_env, each=n)

  ## Generate model matrix
  B <- matrix(0, d+1, d+1)
  causalOrder <- rep(0, d+1)
  causalOrder[causalOrder == 0] <- sample(1:(d+1))
  for(i in 1:(d-1)){
    node <- causalOrder[i]
    possibleParents <- causalOrder[(i+1):(d+1)]
    tmp <- min(c(d+1-i, max_num_parents))
    numberParents <- sample(0:tmp, 1)
    Parents <- sample(possibleParents, numberParents)
    B[node, Parents] <- rep(1, numberParents)
  }
  node <- causalOrder[d]
  ParentYesNo <- rbinom(n=1, size=1, prob=0.5)
  B[node, causalOrder[d+1]] <- ParentYesNo
  Bstruct <- B

  ## PA, CH, MB
  PA <- which(Bstruct[1,] == 1)-1
  CH <- which(Bstruct[,1] == 1)-1
  CHPA <- vector("list", length(CH))
  CHint <- vector("list", length(CH))
  if(length(CH) > 0){
    for(i in 1:length(CH)){
      CHPA[[i]] <- setdiff(which(Bstruct[CH[i]+1,] == 1)-1, 0)
      CHint[[i]] <- possDe(Bstruct, CH[i]+1, type="dag")-1
    }
  }
  MB <- unique(sort(c(unlist(CHPA), CH, PA)))

  ## Sample interventions and add them to a full adjacency matrix
  interventions <- sample(2:(d+1), num_intvars)
  intvars <- (d+2):(d+num_intvars+1)
  for(i in 1:length(interventions)){
    tmpstruct <- rep(0, nrow(Bstruct))
    tmpstruct[interventions[i]] <- 1
    Bstruct <- cbind(Bstruct, unname(tmpstruct))
    Bstruct <- rbind(Bstruct, rep(0, ncol(Bstruct)))
  }

  ## Compute stable and predictive variables
  ind <- (CH+1) %in% interventions
  ind2 <- (CH %in% unique(unlist(CHint[ind])))
  SB <- unique(sort(c(PA, CH[!ind2],
                      setdiff(unlist(CHPA[!ind2]), unique(unlist(CHint[ind]))))))
  # SB <- unique(sort(c(PA, setdiff(MB, unlist(CHint[ind])))))
  # SB <- unique(sort(c(PA, CH[!ind], unlist(CHPA[!ind]))))
  
  ## Sample weights
  B <- Bstruct*matrix(sample(c(-1,1),(d+num_intvars+1)^2, 0.5)*runif((d+num_intvars+1)^2,0.5,1.5),
                      d+num_intvars+1, d+num_intvars+1)

  ## Generate data
  X <- vector("list", num_env)
  ind <- (d+2):(d+num_intvars+1)
  for(e in 1:num_env){
    varvec <- rep(0.25, d+num_intvars+1)
    meanvec <- rep(0, d+num_intvars+1)
    ## Intervention
    if(e <= num_train){
      meanvec[ind] <- runif(length(ind), -intshift_train, intshift_train)
    }
    else{
      meanvec[ind] <- runif(length(ind), -intshift_test, intshift_test)
    }
    eps <- matrix(sapply(1:n, function(x) rnorm(d+num_intvars+1, meanvec, sqrt(varvec))),
                  d+num_intvars+1, n, byrow=F)
    X[[e]] <- t(solve(diag(d+num_intvars+1)-B, eps))
  }
  X <- do.call(rbind, X)
  

  ## Return results
  return(list(env=env,
              X=X[,-c(1, ind)],
              Y=X[,1],
              PA=PA,
              CH=CH,
              interventions=interventions-1,
              MB=MB,
              SB=SB,
              B=B,
              Bstruct=Bstruct))
#              graph=g))

}


###
# Linear DAG model - high dimensional - sparse
###

linear_DAG_model_sparse <- function(d=50, intprob=0.2, num_train=3, num_test=2,
                                    n=100, p_connect=2/d,
                                    intshift_train=0.5, intshift_test=0.5){

  # Generate environment vector
  num_env <- num_train + num_test
  env <- rep(1:num_env, each=n)

  ## Generate model matrix
  B <- matrix(0, d+1, d+1)
  causalOrder <- sample(1:(d+1))
  combinations <- combn(d+1, 2, simplify=FALSE)
  edges <- combinations[sample(c(TRUE, FALSE), length(combinations),
                               replace=TRUE, prob=c(p_connect, 1-p_connect))]
  for(i in 1:length(edges)){
    e1 <- edges[[i]][1]
    e2 <- edges[[i]][2]
    if(which(causalOrder == e1) <= which(causalOrder == e2)){
      B[e2, e1] <- 1
    }
    else{
      B[e1, e2] <- 1
    }
  }
  Bstruct <- B
  #B <- t(apply(B, 1, function(x) x/sqrt(sum(x != 0)+1)))
  B <- Bstruct*matrix(sample(c(-1,1),(d+1)^2, 0.5)*runif((d+1)^2,0.5,1.5),
                      d+1, d+1)
  

  ## PA, CH, MB, SB
  PA <- which(Bstruct[1,] == 1)-1
  CH <- which(Bstruct[,1] == 1)-1
  CHPA <- vector("list", length(CH))
  CHint <- vector("list", length(CH))
  if(length(CH) > 0){
    for(i in 1:length(CH)){
      CHPA[[i]] <- setdiff(which(Bstruct[CH[i]+1,] == 1)-1, 0)
      CHint[[i]] <- possDe(Bstruct, CH[i]+1, type="dag")-1
    }
  }
  MB <- unique(sort(c(unlist(CHPA), CH, PA)))
  ind <- sample(c(TRUE, FALSE), length(CH), replace=TRUE, prob=c(intprob, 1-intprob))
  #interventions <- unique(sort(c(CH[ind] + 1, unlist(CHPA[ind]) + 1)))
  interventions <- unique(sort(CH[ind] + 1))
  ind2 <- (CH %in% unique(unlist(CHint[ind])))
  SB <- unique(sort(c(PA, CH[!ind2],
                      setdiff(unlist(CHPA[!ind2]), unique(unlist(CHint[ind]))))))
  # SB <- unique(sort(c(PA, setdiff(MB, unlist(CHint[ind])))))
  # SB <- unique(sort(c(PA, CH[!ind], unlist(CHPA[!ind]))))

  ## Generate data
  X <- vector("list", num_env)
  for(e in 1:num_env){
    #sdvec <- rep(0.5, d+1)
    #sdvec <- sdvec/(sqrt(1)+1)
    sdvec <- sqrt(0.25)
    meanvec <- rep(0, d+1)
    ## Intervention
    if(e <= num_train){
      meanvec[interventions] <- runif(length(interventions), -intshift_train, intshift_train)
    }
    else{
      meanvec[interventions] <- runif(length(interventions), -intshift_test, intshift_test)
    }
    eps <- matrix(sapply(1:n, function(x) rnorm(d+1, meanvec, sdvec)),
                  d+1, n, byrow=F)
    X[[e]] <- t(solve(diag(d+1)-B, eps))
  }
  X <- do.call(rbind, X)
  

  ## Return results
  return(list(env=env,
              X=X[,-1],
              Y=X[,1],
              PA=PA,
              CH=CH,
              interventions=interventions-1,
              MB=MB,
              SB=SB,
              B=B,
              Bstruct=Bstruct))
}
