library(onehot)


## Lasso variable selection
lasso_variable_selection <- function(x, y){
  fit <- glmnet(x, y)
  sel.matrix <- (fit$beta != 0)
  first.entrance <- apply(sel.matrix, 1, which.max)
  first.entrance[which(apply(sel.matrix, 1, sum) == 0)] <- Inf
  fit <- cv.glmnet(x, y)
  return(list(first.entrance=first.entrance,
              fit=fit))
}

## Variable importance
VariableImportance <- function(df, estimator, B=2, classification=FALSE){
  d <- ncol(df) - 1
  n <- nrow(df)

  variable_importance <- rep(0, d)
  if(classification){
    metric <- function(Yhat){
      return(mean(df[,1] == Yhat))
    }
  }
  else{
    varY <- mean((df[,1] - mean(Y))^2)
    metric <- function(Yhat){
      return(1-mean((df[,1] - Yhat)^2)/varY)
    }
  }
  baseline <- metric(predict(estimator, df))
  for(j in 1:d){
    dftmp <- df
    tmp_imp <- rep(0, B)
    for(i in 1:B){
      dftmp[,j+1] <- dftmp[sample(1:n),j+1]
      tmp_imp[i] <- baseline-metric(predict(estimator, dftmp))
    }
    variable_importance[j] <- mean(tmp_imp)
  }  
  return(variable_importance)
}


## Anchor regression
anchor.regression <- function(X, Y, E, gamma, highdim=FALSE){
  n <- nrow(X)
  d <- ncol(X)
  Y <- matrix(Y, ncol=1)

  anchor_reg <- function(X, Y, E, gamma){
    if(gamma < 0){
      gamma <- 0
    }
    Wgamma <- diag(nrow(E)) - (1-sqrt(gamma))*E%*%solve(t(E)%*%E, t(E))
    Ytilde <- Wgamma %*% Y
    Xtilde <- Wgamma %*% X
    if(highdim){
      fit <- cv.glmnet(Xtilde[,-1,drop=FALSE], Ytilde)
      beta <- coefficients(fit)[,1]
    }
    else{
      fit <- lm.fit(Xtilde, Ytilde)
      beta <- coefficients(fit)
    }
    return(beta)
  }
  
  # Perform anchor regression for cross-validated parameter
  Efull <- as.matrix(model.matrix(~., data.frame(as.factor(E))))
  beta <- anchor_reg(X, Y, Efull, gamma)

  return(beta)
}


## Anchor regression CV
cv.anchor.regression <- function(X, Y, E, highdim=FALSE){
  n <- nrow(X)
  d <- ncol(X)
  Y <- matrix(Y, ncol=1)

  unique_env <- unique(E)
  num_env <- length(unique_env)
  train_sets <- lapply(unique_env, function(e) E != e)

  anchor_reg <- function(X, Y, E, gamma){
    if(gamma < 0){
      gamma <- 0
    }
    Wgamma <- diag(nrow(E)) - (1-sqrt(gamma))*E%*%solve(t(E)%*%E, t(E))
    Ytilde <- Wgamma %*% Y
    Xtilde <- Wgamma %*% X
    if(highdim){
      fit <- cv.glmnet(Xtilde[,-1,drop=FALSE], Ytilde)
      beta <- coefficients(fit)[,1]
    }
    else{
      fit <- lm.fit(Xtilde, Ytilde)
      beta <- coefficients(fit)
    }
    return(beta)
  }
  

  cv_function <- function(gamma){
    loss <- vector("numeric", num_env)
    for(i in 1:num_env){
      train_split <- train_sets[[i]]
      Xtrain <- X[train_split,,drop=FALSE]
      Ytrain <- Y[train_split,,drop=FALSE]
      Etrain <- as.matrix(model.matrix(~., data.frame(as.factor(E[train_split]))))
      Xtest <- X[!train_split,,drop=FALSE]
      Ytest <- Y[!train_split,,drop=FALSE]
      beta <- anchor_reg(Xtrain, Ytrain, Etrain, gamma)
      loss[i] <- mean((Ytest - Xtest %*% matrix(beta, ncol=1))^2)
    }
    return(mean(loss))
  }

  # Perform cross-validation
  opt_res <- optim(1, cv_function, lower=0, upper=1000, method="L-BFGS-B")
  
  # Perform anchor regression for cross-validated parameter
  Efull <- as.matrix(model.matrix(~., data.frame(as.factor(E))))
  beta <- anchor_reg(X, Y, Efull, opt_res$par)

  return(beta)
}
