#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)


data_type <- args[1]
workon <- as.numeric(args[2])
prescreen_size <- as.numeric(args[3])
leave_in <- as.numeric(args[4])

print("Starting computation with:")
print(data_type)
print(workon)
print(prescreen_size)
print(leave_in)


######################################
###
### Detecting new genes
###
######################################

set.seed(1111)

## Load functions and packages
library(parallel)
library(StabilizedRegression)
source("helper_functions.R")


## Load data
load("data/pathway_info.Rda")
if(data_type == "Prot"){
  data <- read.csv("data/preprocessed_protein_data.csv")
  pathway_list <- pathway_info$pathway_list_prot
} else if(data_type == "mRNA"){
  data <- read.csv("data/preprocessed_mRNA_data.csv")
  pathway_list <- pathway_info$pathway_list_mrna
}
group_label <- pathway_info$group_label


## Define settings
cores <- 4
pars <- list(num_reps=200,
             m=6,
             B=5000,
             alpha_stab=0.1,
             alpha_pred=0.01,
             size_weight="linear",
             prescreen_size=prescreen_size,
             use_resampling=FALSE,
             stab_test="exact",
             variable_importance="scaled_coefficient",
             threshold=0)

## Construct pathway genes
Xmat <- as.matrix(data[,-(1:2)])
varsnames <- colnames(Xmat)
env <- data[,2]
pw_genes <- pathway_list[[workon]]


###
# Leave-one-out
###

## Create directory
dirtmp <- "results_recovery"
dir.create(dirtmp, showWarnings = FALSE)
directory <- paste("results_recovery/", group_label[workon], sep="")
dir.create(directory, showWarnings = FALSE)

## Perform current iteration 
print(paste("Working on leave one in number:", leave_in))

## Construct target
varmissing <- pw_genes[-leave_in]
varsin <- pw_genes[leave_in]
Y <- rowMeans(Xmat[,varsnames %in% varsin, drop=FALSE])
Xout <- Xmat[,!(varsnames %in% varsin)]
const_ind <- apply(Xout, 2, function(x) length(unique(x))) <= 100
Xout <- Xout[,!const_ind]
varsout <- colnames(Xout)

###
# Run stability selection
###

res <- stability_selection_wrapper(Xout, Y, env,
                                   num_reps=pars$num_reps, m=pars$m,
                                   B=pars$B,
                                   alpha_stab=pars$alpha_stab,
                                   alpha_pred=pars$alpha_pred,
                                   size_weight=pars$size_weight,
                                   prescreen_size=pars$prescreen_size,
                                   use_resampling=pars$use_resampling,
                                   stab_test=pars$stab_test,
                                   variable_importance=pars$variable_importance,
                                   threshold=pars$threshold,
                                   additional_benchmark=TRUE,
                                   cores=cores)
## Save results
fullres <- list(res=res,
                pars=pars,
                varmissing=varmissing,
                varnames=colnames(Xout))                  
save(fullres,
     file=paste(directory, "/leaveoneout_",
                group_label[workon], "_",
                data_type, "_",
                leave_in,
                ".Rda", sep=""))

warnings()
