###
# Construct plots
###


library(ggplot2)
library(cowplot)
library(RColorBrewer)
library(ggthemes)
library(latex2exp)
library(extrafont)
library(scales)

font_install("fontcm")
loadfonts()
textwidth <- 15.91774/2.54
fontsize <- 9
colors <- c("pink", "orange", "blue", "green", "red")

## Plot theme
theme_set(theme_light())
theme_update(panel.grid.minor=element_blank(),
             panel.grid.major=element_line(size=0.05),
             strip.text = element_text(size=fontsize),
             plot.title = element_text(size=fontsize+1, hjust=0.5),
             axis.text.x = element_text(size=fontsize-1),
             axis.text.y = element_text(size=fontsize-1),
             text=element_text(family="CM Roman", size=fontsize))
cols6 <- hue_pal()(6)
cols7 <- hue_pal()(7)

## Load pathway data
load("data/pathway_info.Rda")
group_label <- pathway_info$group_label  


###
# Function to compute AUROC
###

compute_auroc <- function(res, varnames, true_genes, cutoff=20){

  num_method <- length(res)
  auroc <- vector("numeric", num_method)
  for(i in 1:num_method){
    tmp <- order(res[[i]]$selection_probs, decreasing=T)
    recovery <- cumsum(varnames[tmp] %in% true_genes)/length(true_genes)
    fd <- cumsum(!(varnames[tmp] %in% true_genes))
    c <- which.max(fd > cutoff)-1
    auroc[i] <- sum(diff(fd[1:c]/cutoff)*recovery[2:c])
  }
  return(auroc)
}


###
# Plot functions
###

## Function to construct scatter plot
generate_plots_ggplot <- function(sp_stab, sp_diff, benchmark,
                                  siglevel_stab, siglevel_diff,
                                  beta_sign,
                                  varnames, true_genes, labs=TRUE,
                                  cutoff=20){

  ## Scatter plot
  hit <- (varnames %in% true_genes)
  df <- data.frame(sp_diff=sp_diff, sp_stab=sp_stab, names=varnames,
                   beta_sign=beta_sign, hit=hit)
  splot <- ggplot()
  splot <- splot + geom_rect(aes(xmin=-Inf, xmax=0.5, ymin=-Inf, ymax=0.5), 
                             fill=rgb(1,0,0), alpha=0.2)
  splot <- splot + geom_rect(aes(xmin=siglevel_diff, xmax=Inf, ymin=-Inf, ymax=Inf), 
                             fill=rgb(0,1,0), alpha=0.2)
  splot <- splot + geom_rect(aes(xmin=-Inf, xmax=Inf, ymin=siglevel_stab, ymax=Inf), 
                             fill=rgb(0,1,0), alpha=0.2)
  splot <- splot + geom_point(data=df, aes(x=sp_diff, y=sp_stab, color=beta_sign, shape=hit),
                              cex=1)
  splot <- splot + scale_color_gradient(low = "red", high = "black")
  splot <- splot + scale_shape_manual(values=c(19, 17))
  if(labs){
    splot <- splot + geom_text(data=df, aes(x=sp_diff, y=sp_stab,
                                            label=ifelse(sp_diff > siglevel_diff |
                                                           sp_stab > siglevel_stab,
                                                         as.character(names),'')),
                               hjust=0, vjust=0, size=3, family="CM Roman")
  }
  splot <- splot + xlim(c(0,1)) + ylim(c(0,1))
  splot <- splot + xlab(TeX("selection probability - $NSB_I(Y)$"))
  splot <- splot + ylab(TeX("selection probability - $SB_I(Y)$"))
  splot <- splot + theme(legend.position="none")
  ## Roc plot
  method <- c("SR", names(benchmark))
  sps <- c(list(sp_stab), benchmark)
  df_roc <- data.frame(recovery=NULL, fd=NULL, method=NULL)
  for(i in 1:length(sps)){
    tmp <- order(sps[[i]], decreasing=T)
    recovery <- cumsum(varnames[tmp] %in% true_genes)/length(true_genes)
    fd <- cumsum(!(varnames[tmp] %in% true_genes))
    c <- which.max(fd > cutoff)-1
    df_roc <- rbind(df_roc,
                    data.frame(recovery=c(0, recovery[1:c]),
                               fd=c(0, fd[1:c]),
                               method=rep(method[i], c+1)))
  }
  rplot <- ggplot(df_roc, aes(x=fd, y=recovery, col=method))
  rplot <- rplot + geom_line(alpha=0.75, size=1.1) + geom_point(alpha=0.5, cex=1)
  rplot <- rplot + ylim(c(0,1))
  rplot <- rplot + xlab("number false positives")
  rplot <- rplot + ylab("true positive rate")
  rplot <- rplot + theme(legend.title=element_blank(),
                         legend.position=c(0.48, 0.85),
                         legend.text=element_text(size=fontsize-3),
                         legend.key=element_rect(fill = alpha("white", 0.0)),
                         legend.background=element_rect(fill=alpha('white', 0)),
                         legend.direction="horizontal")
  rplot <- rplot + guides(color=guide_legend(nrow=2,byrow=TRUE))

  return(list(rplot=rplot,
              splot=splot))
}


###
# Create plots and compute auroc for all pathways and envs
###

pathways <- rep(1:31, 2)
data_types <- c("Prot", "mRNA")
df_results <- data.frame(pathway_id=NULL,
                         pathway=NULL,
                         data_type=NULL,
                         env=NULL,
                         method=NULL,
                         auroc=NULL)
for(dt in data_types){
  ## Load data
  if(dt == "Prot"){
    data <- read.csv("data/preprocessed_protein_data.csv")
    pathway_list <- pathway_info$pathway_list_prot
  } else if(dt == "mRNA"){
    data <- read.csv("data/preprocessed_mRNA_data.csv")
    pathway_list <- pathway_info$pathway_list_mrna
  }
  Xmat <- as.matrix(data[,-(1:2)])
  varsnames <- colnames(Xmat)
  env <- data[,2]
  for(pw in 1:length(pathway_list)){
    ## Construct pathway genes
    pw_genes <- pathway_list[[pw]]
    pwname <- group_label[pw]
    for(leave_out in 1:length(pw_genes)){
      varsin <- pw_genes[leave_out]
      pval <- summary(aov(Xmat[,varsnames %in% varsin]~env))[[1]][["Pr(>F)"]][1]
      destfile1 <- paste("results_recovery/",
                         pwname,
                         "/leaveoneout_",
                         pwname, "_",
                         dt, "_",
                         leave_out, ".Rda", sep="")
      if(file.exists(destfile1)){
        load(destfile1)
        vs_results <- fullres$res$vs_results
        ## Create ROC plot
        auroc <- compute_auroc(vs_results, fullres$varnames,
                               fullres$varmissing, cutoff=10)
        ## Add to df_results
        ind <- ifelse("vs_stab" %in% names(vs_results),
                      which(names(vs_results) %in% "vs_stab"),
                      1)
        df_results <- rbind(df_results,
                            data.frame(pathway_id=rep(pw, length(names(vs_results))),
                                       pathway=rep(pwname, length(names(vs_results))),
                                       data_type=rep(dt, length(names(vs_results))),
                                       method=names(vs_results),
                                       auroc=auroc,
                                       delta_auroc=auroc-auroc[ind]))
      }
    }
  }
}


## Load data
dataProt <- read.csv("data/preprocessed_protein_data.csv")
datamRNA <- read.csv("data/preprocessed_mRNA_data.csv")
Xmat_Prot <- as.matrix(dataProt[,-(1:2)])
Xmat_mRNA <- as.matrix(datamRNA[,-(1:2)])
varsall1 <- colnames(Xmat_Prot)
varsall2 <- colnames(Xmat_mRNA)
pathway_list_prot <- pathway_info$pathway_list_prot
pathway_list_mrna <- pathway_info$pathway_list_mrna
diet1 <- dataProt[,2]
diet2 <- datamRNA[,2]
# Nicer pathway names
pwnames_nice <- c("Cholesterol Biosynthesis",
                  "Citric Acid Cycle TCA Cycle",
                  "Respiratory Electron Transport",
                  "Ribosome",
                  "Mitochondrial Ribosome",
                  "Proteasome",
                  "Oxphos NoATPase")

## Generate plots
data.labs <- c("protein", "mRNA")
names(data.labs) <- c("Prot", "mRNA")
for(pw in 1:length(pwnames_nice)){
  for(dt in data_types){
    pwname <- pwnames_nice[pw]
    pwgenes1 <- pathway_list_prot[[pw]]
    pwgenes2 <- pathway_list_mrna[[pw]]
    ## Check effect strength
    if(dt == "Prot"){
      pval <- summary(aov(rowMeans(
        Xmat_Prot[,varsall1 %in% pwgenes1])~diet1))[[1]][["Pr(>F)"]][1]
    } else{
      pval <- summary(aov(rowMeans(
        Xmat_mRNA[,varsall2 %in% pwgenes2])~diet2))[[1]][["Pr(>F)"]][1]
    }
    ## Work with that environment
    df_tmp <- df_results[(df_results$pathway_id == pw &
                            df_results$data_type == dt),]
    means_auroc <- sapply(split(df_tmp$auroc, df_tmp$method), mean)
    if(max(means_auroc) >= 0){
      print(paste("Working on pathway:", pwname))
      print(paste(dt, max(means_auroc)))
      print(paste("Effect:", pval))
      df_tmp <- df_tmp[df_tmp$method %in% c("vs_stab", "vs_predenv",
                                            "vs_corr", "vs_correnv",
                                            "vs_lasso", "vs_iv", "vs_ridge"),]
      df_tmp$method <- droplevels(df_tmp$method)
      df_tmp$method <- factor(df_tmp$method,
                              levels(df_tmp$method)[c(1, 2, 3, 4, 6, 5, 7)])
      ## CHECK whether levels match
      levels(df_tmp$method) <- c("corr", "corr (env)", "IV (Lasso)", "Lasso",
                                 "Ridge", "SRpred", "SR")
      ## Standard plot
      p <- ggplot(df_tmp, aes(x=method, y=auroc, fill=method))
      p <- p + scale_fill_manual(values=cols7)
      p <- p + geom_boxplot()
      p <- p + xlab("") + ylab("pAUC")
      p <- p + theme(legend.position="none",
                     legend.title=element_blank(),
                     axis.text.x = element_text(angle=25, hjust=1))
      ## Relative plot
      df_tmp <- df_tmp[df_tmp$method != "SR",]
      df_tmp$method <- droplevels(df_tmp$method)
      q <- ggplot(df_tmp, aes(x=method, y=delta_auroc, fill=method))
      q <- q + scale_fill_manual(values=cols7)
      q <- q + geom_abline(intercept=0, slope=0, color="red")
      q <- q + geom_boxplot()
      q <- q + xlab("") + ylab("relative pAUC")
      q <- q + theme(legend.position="none",
                     legend.title=element_blank(),
                     axis.text.x = element_text(angle=25, hjust=1))
      ## Title
      title <- ggdraw() + draw_label(paste(pwname, " - diet, ",
                                           ifelse(dt == "mRNA", "mRNA", "protein"), sep=""),
                                     fontfamily="CM Roman", size=fontsize)
      ## Combine
      fullplot <- plot_grid(p, q, ncol=2, rel_widths=c(0.5, 0.5))
      fullplot <- plot_grid(title, fullplot, ncol=1, rel_heights=c(0.1, 0.9))
      ## Save
      filename <- paste("plots_paper/",
                        group_label[pw], "_", dt, ".pdf", sep="")
      ggsave(filename,
             fullplot, width=textwidth, height=0.33*textwidth)
      embed_fonts(filename,
              outfile=filename)
    }
  }
}



###
# Construct example plot for one individual left-out gene
###

## Settings
data_type <- rep("mRNA", 5)
env_type <- rep("diet", 5)
workon <- rep(4, 5)
leave_out <- c(30,31,32,33,34)
settings <- data.frame(data_type=data_type,
                       env_type=env_type,
                       workon=workon,
                       leave_out=leave_out)
for(k in 1:nrow(settings)){
  # Select data
  if(settings$data_type[k] == "Prot"){
    Xmat <- Xmat_Prot
    varsnames <- varsall1
    pathway_list <- pathway_info$pathway_list_prot
  } else{
    Xmat <- Xmat_mRNA
    varsnames <- varsall2
    pathway_list <- pathway_info$pathway_list_mrna
  }
  pwname <- group_label[settings$workon[k]]
  pwname2 <- pwnames_nice[settings$workon[k]]
  pw_genes <- pathway_list[[settings$workon[k]]]
  varsin <- pw_genes[settings$leave_out[k]]
  # Load results
  load(paste("results_recovery/",
             pwname,
             "/leaveoneout_",
             pwname, "_",
             settings$data_type[k], "_",
             settings$leave_out[k], ".Rda", sep=""))  
  sp_stab <- fullres$res$vs_results[["vs_stab"]]$selection_probs
  sp_diff <- fullres$res$vs_results[["vs_diff"]]$selection_probs
  siglevel_stab <- fullres$res$vs_results[["vs_stab"]]$siglevel
  siglevel_diff <- fullres$res$vs_results[["vs_diff"]]$siglevel
  beta_sign <- fullres$res$beta_stab[-1]
  benchmark <- lapply(fullres$res$vs_results, function(x) x$selection_probs)
  names(benchmark) <- names(fullres$res$vs_results)
  ### CUSTOM labels
  benchmark <- benchmark[
    names(benchmark) %in% c("vs_predenv", "vs_corr",
                            "vs_correnv", "vs_lasso",
                            "vs_ridge", "vs_iv")]
  print(names(benchmark))
  names(benchmark) <- c("SRpred", "Lasso", "Ridge", "Corr", "Corr (env)", "IV (Lasso)")
  print(names(benchmark))
  # Generate plot
  plots <- generate_plots_ggplot(sp_stab, sp_diff, benchmark,
                                 siglevel_stab, siglevel_diff,
                                 beta_sign,
                                 fullres$varnames, pw_genes[-settings$leave_out[k]], labs=FALSE,
                                 cutoff=10)
  fullplot <- plot_grid(plots$splot, plots$rplot, ncol=2, rel_heights=c(0.4, 0.6))
  title <- ggdraw() + draw_label(paste(varsin, " (",
                                       pwname2, " - ", settings$env_type[k], ", ",
                                       ifelse(settings$data_type[k] == "mRNA", "mRNA", "protein"),
                                       ")", sep=""),
                                 fontfamily="CM Roman", size=fontsize)
  fullplot <- plot_grid(title, fullplot, ncol=1, rel_heights=c(0.1, 1))
  # Save plot
  filename <- paste("plots_paper/illustrativeplot_",
                    pwname, "_",
                    settings$data_type[k], "_",
                    settings$env_type[k], "_",
                    varsin,
                    ".pdf", sep="")
  save_plot(filename,
            fullplot,
            base_width=textwidth, base_height=textwidth*0.5)
  embed_fonts(filename,
              outfile=filename)
}
