library(glmnet)
library(corpcor)


## Stability selection wrapper
stability_selection_wrapper <- function(X, Y, env, num_reps, m, B,
                                        alpha_stab, alpha_pred,
                                        size_weight, prescreen_size,
                                        use_resampling, stab_test,
                                        variable_importance,
                                        threshold,
                                        additional_benchmark=TRUE,
                                        cores=4){
  
  n <- length(Y)
  
  ## Function for a single application
  single_iteration <- function(i){
    print(i)
    ind <- sample(1:n, floor(n/2), replace=TRUE)


    # SR - corr
    fit <- StabilizedRegression(X[ind,,drop=FALSE], Y[ind], env[ind],
                                list(m=m, B=B,
                                     alpha_stab=alpha_stab,
                                     alpha_pred=alpha_pred,
                                     size_weight=size_weight,
                                     prescreen_size=prescreen_size,
                                     prescreen_type="correlation",
                                     use_resampling=use_resampling,
                                     compute_predictive_model=TRUE,
                                     stab_test=stab_test,
                                     pred_score="mse",
                                     variable_importance=variable_importance),
                                verbose=FALSE)
    vs_stab <- fit$variable_importance
    vs_pred <- fit$variable_importance_pred
    beta_stab <- coef(fit)
    beta_pred <- coef(fit, predictive_model=TRUE)
    
    # SR - correnv
    fit <- StabilizedRegression(X[ind,,drop=FALSE], Y[ind], env[ind],
                                list(m=m, B=B,
                                     alpha_stab=alpha_stab,
                                     alpha_pred=alpha_pred,
                                     size_weight=size_weight,
                                     prescreen_size=prescreen_size,
                                     prescreen_type="correlation_env",
                                     use_resampling=use_resampling,
                                     compute_predictive_model=TRUE,
                                     stab_test=stab_test,
                                     pred_score="mse_env",
                                     variable_importance=variable_importance),
                                verbose=FALSE)
    vs_stabenv <- fit$variable_importance
    vs_predenv <- fit$variable_importance_pred
    vs_diff <- vs_predenv - vs_stab
    beta_stabenv <- coef(fit)
    beta_predenv <- coef(fit, predictive_model=TRUE)
    vs_combined <- apply(cbind(vs_stab, vs_predenv), 1, max)

    # Lasso (first entry)
    fitlasso <- glmnet(X[ind,,drop=FALSE], Y[ind])
    sel.matrix <- (fitlasso$beta != 0)
    first.entrance <- apply(sel.matrix, 1, which.max)
    first.entrance[which(apply(sel.matrix, 1, sum) == 0)] <- Inf
    vs_lasso <- 1/first.entrance

    # Lasso (coefficient)
    fitlasso2 <- cv.glmnet(X[ind,,drop=FALSE], Y[ind], alpha=1)
    vs_lasso2 <- abs(coefficients(fitlasso2)[-1]/apply(X[ind,,drop=FALSE], 2, sd))
    
    # Ridge
    fitridge <- cv.glmnet(X[ind,,drop=FALSE], Y[ind], alpha=0)
    vs_ridge <- abs(coefficients(fitridge)[-1]/apply(X[ind,,drop=FALSE], 2, sd))
      
    # Correlation
    pval <- apply(X[ind,,drop=FALSE], 2, function(x) cor.test(Y[ind], x)$p.value)
    vs_corr <- 1-pval

    # Correlation (env)
    Alist <- lapply(unique(env[ind]), function(a) which(env[ind] == a))
    pval <- apply(X[ind,,drop=FALSE], 2,
                  function(x) sapply(Alist,
                                     function(Aind)
                                       cor.test(Y[ind][Aind],
                                                x[Aind])$p.value))
    pval <- apply(pval, 2, min)
    vs_correnv <- 1-pval
    
    # IV regression
    fit_iv <- anchor.regression(cbind(1, X[ind,,drop=FALSE]),
                                Y[ind], env[ind], gamma=1000, highdim=TRUE)
    vs_iv <- abs(fit_iv[-1]*apply(X[ind,,drop=FALSE], 2, sd))

    # Benchmark methods
    if(additional_benchmark){
      # SR - deconf
      fit <- StabilizedRegression(X[ind,,drop=FALSE], Y[ind], env[ind],
                                  list(m=m, B=B,
                                       alpha_stab=alpha_stab,
                                       alpha_pred=alpha_pred,
                                       size_weight=size_weight,
                                       prescreen_size=prescreen_size,
                                       prescreen_type="deconfounding",
                                       use_resampling=use_resampling,
                                       compute_predictive_model=TRUE,
                                       stab_test=stab_test,
                                       pred_score="mse",
                                       variable_importance=variable_importance),
                                  verbose=FALSE)
      vs_stabdeconf <- fit$variable_importance
      vs_preddeconf <- fit$variable_importance_pred
      beta_stabdeconf <- coef(fit)
      beta_preddeconf <- coef(fit, predictive_model=TRUE)
      
      # SR - deconfenv
      fit <- StabilizedRegression(X[ind,,drop=FALSE], Y[ind], env[ind],
                                  list(m=m, B=B,
                                       alpha_stab=alpha_stab,
                                       alpha_pred=alpha_pred,
                                       size_weight=size_weight,
                                       prescreen_size=prescreen_size,
                                       prescreen_type="deconfounding_env",
                                       use_resampling=use_resampling,
                                       compute_predictive_model=TRUE,
                                       stab_test=stab_test,
                                       pred_score="mse_env",
                                       variable_importance=variable_importance),
                                  verbose=FALSE)
      vs_stabdeconfenv <- fit$variable_importance
      vs_preddeconfenv <- fit$variable_importance_pred
      beta_stabdeconfenv <- coef(fit)
      beta_preddeconfenv <- coef(fit, predictive_model=TRUE)
      vs_combineddeconf <- apply(cbind(vs_stabdeconf, vs_preddeconfenv), 1, max)

      # Correlation (deconfounding)
      fitcorr <- deconfounding_correlation(X[ind,,drop=FALSE], Y[ind])
      vs_corrdeconf <- abs(fitcorr)[-1]
    }
    else{
      vs_corrdeconf <- NA
      vs_stabdeconf <- NA
      vs_stabdeconfenv <- NA
      vs_preddeconf <- NA
      vs_preddeconfenv <- NA
      vs_combineddeconf <- NA
      beta_stabdeconf <- NA
      beta_stabdeconfenv <- NA
      beta_preddeconf <- NA
      beta_preddeconfenv <- NA
    }
    
    return(list(vs_stab=vs_stab,
                vs_pred=vs_pred,
                vs_diff=vs_diff,
                vs_combined=vs_combined,
                vs_stabenv=vs_stabenv,
                vs_predenv=vs_predenv,
                vs_stabdeconf=vs_stabdeconf,
                vs_preddeconf=vs_preddeconf,
                vs_stabdeconfenv=vs_stabdeconfenv,
                vs_preddeconfenv=vs_preddeconfenv,
                vs_combineddeconf=vs_combineddeconf,
                vs_lasso=vs_lasso,
                vs_lasso2=vs_lasso2,
                vs_ridge=vs_ridge,
                vs_corr=vs_corr,
                vs_correnv=vs_correnv,
                vs_corrdeconf=vs_corrdeconf,
                vs_iv=vs_iv,
                beta_stab=beta_stab,
                beta_pred=beta_pred,
                beta_stabenv=beta_stabenv,
                beta_predenv=beta_predenv,
                beta_stabdeconf=beta_stabdeconf,
                beta_preddeconf=beta_preddeconf,
                beta_stabdeconfenv=beta_stabdeconfenv,
                beta_preddeconfenv=beta_preddeconfenv))
  }
  ## Apply bootstrap
  ## results <- lapply(1:num_reps,
  ##                  function(i) single_iteration(i))
  results <- mclapply(1:num_reps,
                      function(i) single_iteration(i),
                      mc.cores=cores)


  ## Output potential error and remove it
  wrongvec <- sapply(results, length) == 1
  if(sum(wrongvec) > 0){
    print(results[wrongvec])
    results <- results[!wrongvec]
    num_reps <- length(results)
  }

  
  ## Iterate over all methods
  vs_ind <- startsWith(names(results[[1]]), "vs")
  num_methods <- sum(vs_ind)
  method_name <- vector("numeric", num_methods)
  vs_results <- vector("list", num_methods)
  for(i in 1:num_methods){
    method_name[i] <- as.character(names(results[[1]][vs_ind][i]))
    vs_score <- t(sapply(results, function(x) x[vs_ind][[i]]))
    ## Compute selection probabilities
    selection_ind <- matrix(FALSE, nrow(vs_score), ncol(vs_score))
    q_est <- mean(apply(cbind(rowSums(vs_score > threshold),
                              rep(floor(sqrt(ncol(vs_score)*0.5*1)),
                                  nrow(vs_score))),
                        1, min))
    for(k in 1:nrow(vs_score)){
      tmpvec <- order(vs_score[k,], decreasing=TRUE)
      num_select <- min(c(sum(vs_score[k,] > threshold),
                          floor(sqrt(ncol(vs_score)*0.5*1))), na.rm=T)
      selection_ind[k, tmpvec[1:num_select]] <- TRUE
    }
    selection_probs <- colMeans(selection_ind)
    false_discovery <- ceiling(1/(2*selection_probs-1)*(q_est^2)/(ncol(vs_score)))
    false_discovery[selection_probs <= 0.5] <- NA  
    siglevel <- (q_est^2/ncol(vs_score)+1)/2
    ## Collect results
    vs_results[[i]]$selection_probs <- selection_probs
    vs_results[[i]]$false_discovery <- false_discovery
    vs_results[[i]]$siglevel <- siglevel
    vs_results[[i]]$q_est <- q_est
  }
  names(vs_results) <- method_name

  ## Compute average coefficient sign
  betamat_pred <- sapply(results, function(x) sign(x$beta_predenv))
  beta_pred <- apply(betamat_pred, 1,
                     function(x) mean(x[x != 0]==1))
  betamat_stab <- sapply(results, function(x) sign(x$beta_stab))
  beta_stab <- apply(betamat_stab, 1,
                     function(x) mean(x[x != 0]==1))

  ## Compute variance in coefficients
  betamat_pred <- sapply(results, function(x) x$beta_predenv)
  betamat_stab <- sapply(results, function(x) x$beta_stab)

  ## Output results
  fullresults <- list(vs_results=vs_results,
                      beta_pred=beta_pred,
                      beta_stab=beta_stab,
                      betamat_stab=betamat_stab,
                      betamat_pred=betamat_pred)
}



deconfounding_correlation <- function(Xmat, Y){
  Xmat <- cbind(Y, Xmat)
  n <- nrow(Xmat)
  d <- ncol(Xmat)
  Xmat <- (Xmat-matrix(colMeans(Xmat), n, d, byrow=T))/matrix(apply(Xmat, 2, sd),
                                                              n, d, byrow=T)
  ## subsample if n too large
  B <- 20
  corrmat <- matrix(NA, B, d)
  num_var <- sqrt(d)
  if(num_var < n){
    for(i in 1:B){
      svd_fit <- corpcor::fast.svd(Xmat[sample(1:n, num_var,
                                               replace=TRUE),,drop=FALSE])
      corrmat[i,] <- (svd_fit$v %*% t(svd_fit$v))[1,]
    }
    corrvec <- colMeans(corrmat)
  }
  else{
    svd_fit <- corpcor::fast.svd(Xmat)
    corrvec <- (svd_fit$v %*% t(svd_fit$v))[1,]
  }
  return(corrvec)
}



## Anchor regression
anchor.regression <- function(X, Y, E, gamma, highdim=FALSE){
  n <- nrow(X)
  d <- ncol(X)
  Y <- matrix(Y, ncol=1)

  anchor_reg <- function(X, Y, E, gamma){
    if(gamma < 0){
      gamma <- 0
    }
    Wgamma <- diag(nrow(E)) - (1-sqrt(gamma))*E%*%solve(t(E)%*%E, t(E))
    Ytilde <- Wgamma %*% Y
    Xtilde <- Wgamma %*% X
    if(highdim){
      fit <- cv.glmnet(Xtilde[,-1,drop=FALSE], Ytilde)
      beta <- coefficients(fit)[,1]
    }
    else{
      fit <- lm.fit(Xtilde, Ytilde)
      beta <- coefficients(fit)
    }
    return(beta)
  }
  
  # Perform anchor regression for cross-validated parameter
  Efull <- as.matrix(model.matrix(~., data.frame(as.factor(E))))
  beta <- anchor_reg(X, Y, Efull, gamma)

  return(beta)
}
