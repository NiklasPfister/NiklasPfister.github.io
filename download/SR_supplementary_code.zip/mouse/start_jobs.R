### Start all jobs
load("data/pathway_info.Rda")

data_type <- c("mRNA", "Prot")
workon <- 1:7
prescreen_size <- 50

print(getwd())


for(dt in data_type){
  ## Load data to check how many genes
  if(dt == "mRNA"){
    pathway_list <- pathway_info$pathway_list_mrna
  }
  else{
    pathway_list <- pathway_info$pathway_list_prot
  }
  for(k in 1:length(workon)){
    num_genes <- length(pathway_list[[workon[k]]])
    print(num_genes)
    for(leave_in in 1:num_genes){
      jobname <- paste(dt, workon[k], leave_in, sep="_")
      job_string <- paste("qsub -o logs/output_", jobname, ".txt -e logs/error_",
                          jobname, ".txt qsub_submission_script_", dt, ".sh -F '",
                          dt, " ", workon[k], " ", prescreen_size, " ",
                          leave_in, "'", sep="")
      system(job_string)
    }
  }
}
