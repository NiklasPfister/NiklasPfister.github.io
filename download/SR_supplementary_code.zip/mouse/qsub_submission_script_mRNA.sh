#!/usr/bin/bash

#PBS -W group_list=ku_00028 -A ku_00028
#PBS -l nodes=1:ppn=4
#PBS -l mem=40gb
#PBS -l walltime=12:00:00


## Load modules
module load tools
module load gcc
module load intel/perflibs
module load R/3.6.1

echo We are in the $PWD directory
cd $PBS_O_WORKDIR
echo We are now in $PBS_O_WORKDIR, running an R script.

Rscript --vanilla recovery_analysis.R $1 $2 $3 $4 > logs/analysis_$1_$2_$3_$4.log
